# coding: utf-8



__version__ = '0.3'
__author__ = 'Hsiaoming Yang <me@lepture.com>'
__homepage__ = 'https://github.com/lepture/captcha'
