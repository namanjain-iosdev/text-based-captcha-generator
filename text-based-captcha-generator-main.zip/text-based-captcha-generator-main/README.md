# A Text Based Captcha Generator
# Contributors
-@akshaysingh02
-@architnagpal001
-@naman2001jain

# Required Modules
-tkinter
-random
-captcha

# Description
To Run this program, you need to run main.py file and further files will be automatically running as program flows...
This Generates a Login interface Which is having some Entry widgets to take input of username, password and captcha. When you will click on Go button, Python will check the captcha if it is correct or not. If Entered captcha is correct the status of status bar will be changed(color=green and text=successful). If the Entered captcha is wrong then the status bar will be changed(color=red and text=invalid).
