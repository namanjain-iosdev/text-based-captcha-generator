from interface import login_screen

if __name__ == '__main__':
    login_screen()  # initiates login screen

